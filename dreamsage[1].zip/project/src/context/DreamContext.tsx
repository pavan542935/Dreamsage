import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Dream {
  id: string;
  content: string;
  emotions: string[];
  date: string;
}

interface DreamContextType {
  userDreams: Dream[];
  addDream: (dream: Dream) => void;
  removeDream: (id: string) => void;
}

const DreamContext = createContext<DreamContextType | undefined>(undefined);

export const useDreams = () => {
  const context = useContext(DreamContext);
  if (context === undefined) {
    throw new Error('useDreams must be used within a DreamProvider');
  }
  return context;
};

interface DreamProviderProps {
  children: ReactNode;
}

export const DreamProvider: React.FC<DreamProviderProps> = ({ children }) => {
  const [userDreams, setUserDreams] = useState<Dream[]>([
    {
      id: '1',
      content: 'I was flying over a beautiful landscape. I could feel the wind against my face and I had a sense of complete freedom.',
      emotions: ['Joy', 'Peace', 'Excitement'],
      date: '2025-03-15T08:30:00Z'
    }
  ]);
  
  const addDream = (dream: Dream) => {
    setUserDreams(prevDreams => [dream, ...prevDreams]);
  };
  
  const removeDream = (id: string) => {
    setUserDreams(prevDreams => prevDreams.filter(dream => dream.id !== id));
  };
  
  return (
    <DreamContext.Provider value={{ userDreams, addDream, removeDream }}>
      {children}
    </DreamContext.Provider>
  );
};