import React, { createContext, useContext, useState, ReactNode } from 'react';

interface UserProfile {
  id: string;
  name: string;
  email: string;
  joinDate: string;
}

interface AuthContextType {
  isAuthenticated: boolean;
  userProfile: UserProfile | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  // For demo purposes, we'll set the user as already authenticated
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  const [userProfile, setUserProfile] = useState<UserProfile | null>({
    id: '1',
    name: 'Dream Explorer',
    email: 'user@example.com',
    joinDate: 'February 2025'
  });
  
  const login = async (email: string, password: string) => {
    // Mock authentication logic
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        setIsAuthenticated(true);
        setUserProfile({
          id: '1',
          name: 'Dream Explorer',
          email: email,
          joinDate: 'February 2025'
        });
        resolve();
      }, 1000);
    });
  };
  
  const logout = () => {
    setIsAuthenticated(false);
    setUserProfile(null);
  };
  
  return (
    <AuthContext.Provider value={{ isAuthenticated, userProfile, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};