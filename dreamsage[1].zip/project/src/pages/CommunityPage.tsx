import React, { useState } from 'react';
import { Search, Filter, ThumbsUp, MessageSquare, EyeOff } from 'lucide-react';
import DreamCard from '../components/community/DreamCard';

// Mock community dream data
const communityDreams = [
  {
    id: '1',
    title: 'Flying over mountains',
    content: 'I was flying over beautiful snow-capped mountains. The sensation was exhilarating and I felt completely free.',
    emotions: ['Joy', 'Peace', 'Excitement'],
    author: 'Anonymous',
    likes: 24,
    comments: 8,
    date: '2025-02-15',
    tags: ['flying', 'nature', 'freedom']
  },
  {
    id: '2',
    title: 'Being chased in a maze',
    content: 'I was trapped in an endless maze with something chasing me. I kept running but couldn\'t find the exit.',
    emotions: ['Fear', 'Anxiety', 'Confusion'],
    author: 'Anonymous',
    likes: 18,
    comments: 12,
    date: '2025-02-14',
    tags: ['chase', 'maze', 'nightmare']
  },
  {
    id: '3',
    title: 'Meeting a deceased relative',
    content: 'My grandmother who passed away years ago visited me. She looked peaceful and gave me important advice about my life.',
    emotions: ['Sadness', 'Peace', 'Love'],
    author: 'Anonymous',
    likes: 32,
    comments: 15,
    date: '2025-02-13',
    tags: ['deceased', 'family', 'visitation']
  },
  {
    id: '4',
    title: 'Teeth falling out',
    content: 'All my teeth started crumbling and falling out. I was at an important event and felt embarrassed and helpless.',
    emotions: ['Anxiety', 'Fear', 'Confusion'],
    author: 'Anonymous',
    likes: 42,
    comments: 28,
    date: '2025-02-12',
    tags: ['teeth', 'common', 'stress']
  }
];

// Mock tags for filtering
const dreamTags = [
  'flying', 'falling', 'chase', 'teeth', 'water', 
  'deceased', 'family', 'work', 'school', 'naked',
  'unprepared', 'lost', 'nightmare', 'lucid', 'recurring'
];

const CommunityPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('recent');
  const [showFilters, setShowFilters] = useState(false);
  
  const handleTagSelect = (tag: string) => {
    setActiveTag(activeTag === tag ? null : tag);
  };
  
  const filteredDreams = communityDreams.filter(dream => {
    // Filter by search term
    const matchesSearch = searchTerm === '' || 
      dream.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dream.content.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filter by tag
    const matchesTag = activeTag === null || dream.tags.includes(activeTag);
    
    return matchesSearch && matchesTag;
  });
  
  // Sort dreams based on active filter
  const sortedDreams = [...filteredDreams].sort((a, b) => {
    if (activeFilter === 'recent') {
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    } else if (activeFilter === 'popular') {
      return b.likes - a.likes;
    } else if (activeFilter === 'discussed') {
      return b.comments - a.comments;
    }
    return 0;
  });
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-slate-900 dark:text-white">Dream Community</h1>
          <p className="text-lg text-slate-600 dark:text-slate-300">
            Explore dreams shared by others and gain collective insights.
          </p>
        </div>
        
        <div className="mt-4 md:mt-0">
          <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg shadow-md hover:shadow-lg transition-all">
            Share Your Dream
          </button>
        </div>
      </div>
      
      <div className="mb-6">
        <div className="relative">
          <input
            type="text"
            placeholder="Search dreams by content or symbols..."
            className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-3 h-5 w-5 text-slate-400" />
        </div>
      </div>
      
      <div className="mb-6 flex justify-between items-center">
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveFilter('recent')}
            className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors ${
              activeFilter === 'recent'
                ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600'
            }`}
          >
            Recent
          </button>
          <button
            onClick={() => setActiveFilter('popular')}
            className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors flex items-center ${
              activeFilter === 'popular'
                ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600'
            }`}
          >
            <ThumbsUp className="h-4 w-4 mr-1" />
            Popular
          </button>
          <button
            onClick={() => setActiveFilter('discussed')}
            className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors flex items-center ${
              activeFilter === 'discussed'
                ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600'
            }`}
          >
            <MessageSquare className="h-4 w-4 mr-1" />
            Most Discussed
          </button>
        </div>
        
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 transition-colors flex items-center"
          aria-expanded={showFilters}
          aria-label="Show filters"
        >
          <Filter className="h-5 w-5" />
        </button>
      </div>
      
      {/* Tag filters */}
      {showFilters && (
        <div className="mb-6 p-4 bg-white dark:bg-slate-800 rounded-lg shadow-md">
          <h3 className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">
            Filter by Dream Symbols & Themes
          </h3>
          <div className="flex flex-wrap gap-2">
            {dreamTags.map(tag => (
              <button
                key={tag}
                onClick={() => handleTagSelect(tag)}
                className={`px-3 py-1 text-xs font-medium rounded-full capitalize transition-colors ${
                  activeTag === tag
                    ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300 ring-1 ring-purple-400'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* Content warning for sensitive dreams */}
      <div className="mb-6 p-4 bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-lg flex items-start">
        <EyeOff className="h-5 w-5 text-amber-600 dark:text-amber-400 mr-3 mt-0.5 flex-shrink-0" />
        <div>
          <h3 className="font-medium text-amber-800 dark:text-amber-300">Content Warning</h3>
          <p className="text-sm text-amber-700 dark:text-amber-400">
            Some dreams may contain disturbing content. We use AI moderation, but please use discretion when browsing.
          </p>
        </div>
      </div>
      
      {/* Dream cards */}
      <div className="space-y-6">
        {sortedDreams.length > 0 ? (
          sortedDreams.map(dream => (
            <DreamCard 
              key={dream.id}
              dream={dream}
            />
          ))
        ) : (
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-8 text-center">
            <p className="text-slate-600 dark:text-slate-300 mb-2">No dreams match your search criteria.</p>
            <button
              onClick={() => {
                setSearchTerm('');
                setActiveTag(null);
              }}
              className="text-purple-600 dark:text-purple-400 hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CommunityPage;