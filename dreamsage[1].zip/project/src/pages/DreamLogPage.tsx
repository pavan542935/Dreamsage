import React, { useState } from 'react';
import { Save, Mic, MicOff, AlertCircle } from 'lucide-react';
import DreamInterpretation from '../components/dreams/DreamInterpretation';
import EmotionTag from '../components/dreams/EmotionTag';
import { useDreams } from '../context/DreamContext';

const emotions = [
  'Joy', 'Fear', 'Sadness', 'Anger', 
  'Confusion', 'Surprise', 'Anxiety', 'Peace',
  'Excitement', 'Love'
];

const DreamLogPage: React.FC = () => {
  const [dreamContent, setDreamContent] = useState('');
  const [selectedEmotions, setSelectedEmotions] = useState<string[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [showInterpretation, setShowInterpretation] = useState(false);
  const { addDream } = useDreams();
  
  // Mock function for voice recording toggle
  const toggleRecording = () => {
    setIsRecording(!isRecording);
    // In a real app, we would initialize the SpeechRecognition API here
  };
  
  const handleEmotionToggle = (emotion: string) => {
    if (selectedEmotions.includes(emotion)) {
      setSelectedEmotions(selectedEmotions.filter(item => item !== emotion));
    } else {
      setSelectedEmotions([...selectedEmotions, emotion]);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (dreamContent.trim().length < 10) {
      alert('Please provide more details about your dream.');
      return;
    }
    
    // In a real app, this would send data to the server and get AI interpretation
    const newDream = {
      id: Date.now().toString(),
      content: dreamContent,
      emotions: selectedEmotions,
      date: new Date().toISOString(),
    };
    
    addDream(newDream);
    setShowInterpretation(true);
  };
  
  const resetForm = () => {
    setDreamContent('');
    setSelectedEmotions([]);
    setShowInterpretation(false);
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-bold mb-2 text-slate-900 dark:text-white">Dream Journal</h1>
      <p className="text-lg text-slate-600 dark:text-slate-300 mb-8">
        Record your dream and receive AI-powered interpretations.
      </p>
      
      {!showInterpretation ? (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6">
            <div className="mb-4">
              <label htmlFor="dreamContent" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Describe your dream in detail
              </label>
              <div className="relative">
                <textarea
                  id="dreamContent"
                  rows={6}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none transition-all"
                  placeholder="What happened in your dream? Who was there? How did you feel?"
                  value={dreamContent}
                  onChange={(e) => setDreamContent(e.target.value)}
                  required
                ></textarea>
                <button
                  type="button"
                  onClick={toggleRecording}
                  className={`absolute bottom-3 right-3 p-2 rounded-full ${
                    isRecording 
                      ? 'bg-red-100 text-red-600 dark:bg-red-900 dark:text-red-300' 
                      : 'bg-slate-100 text-slate-600 dark:bg-slate-600 dark:text-slate-300'
                  } hover:bg-opacity-80 transition-colors`}
                  aria-label={isRecording ? 'Stop recording' : 'Start recording'}
                >
                  {isRecording ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                </button>
              </div>
              <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                Provide as many details as you can remember
              </p>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                How did you feel in the dream?
              </label>
              <div className="flex flex-wrap gap-2">
                {emotions.map(emotion => (
                  <EmotionTag
                    key={emotion}
                    emotion={emotion}
                    isSelected={selectedEmotions.includes(emotion)}
                    onToggle={() => handleEmotionToggle(emotion)}
                  />
                ))}
              </div>
            </div>
            
            <div className="mt-6">
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Did this dream relate to any recent life events?
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                placeholder="Optional: Describe any connections to your waking life"
              />
            </div>
          </div>
          
          <div className="flex justify-end">
            <button
              type="submit"
              className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg shadow-md hover:shadow-lg transition-all flex items-center"
              disabled={dreamContent.trim().length < 10}
            >
              <Save className="mr-2 h-5 w-5" />
              <span>Save & Interpret Dream</span>
            </button>
          </div>
        </form>
      ) : (
        <div className="space-y-8">
          <DreamInterpretation 
            dreamContent={dreamContent}
            emotions={selectedEmotions}
          />
          
          <div className="flex justify-center">
            <button
              onClick={resetForm}
              className="px-6 py-3 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-white rounded-lg transition-all"
            >
              Log Another Dream
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default DreamLogPage;