import React, { useState } from 'react';
import { Calendar, ChevronLeft, ChevronRight, Bookmark, Settings, LineChart, Clock } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useDreams } from '../context/DreamContext';
import DreamCard from '../components/community/DreamCard';

const ProfilePage: React.FC = () => {
  const { userProfile } = useAuth();
  const { userDreams } = useDreams();
  const [activeTab, setActiveTab] = useState('journal');
  const [currentMonth, setCurrentMonth] = useState(new Date());
  
  // Format the current month and year for display
  const formattedMonth = currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  
  // Navigate to previous month
  const goToPreviousMonth = () => {
    const previousMonth = new Date(currentMonth);
    previousMonth.setMonth(previousMonth.getMonth() - 1);
    setCurrentMonth(previousMonth);
  };
  
  // Navigate to next month
  const goToNextMonth = () => {
    const nextMonth = new Date(currentMonth);
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    setCurrentMonth(nextMonth);
  };
  
  // Get days in month for calendar display
  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDayOfMonth = new Date(year, month, 1).getDay();
    
    // Generate days for calendar grid
    const calendarDays = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDayOfMonth; i++) {
      calendarDays.push({ day: '', hasDream: false, isCurrentMonth: false });
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      // Random chance of having a dream (for demo purposes)
      const hasDream = Math.random() > 0.7;
      calendarDays.push({ day, hasDream, isCurrentMonth: true });
    }
    
    return calendarDays;
  };
  
  const calendarDays = getDaysInMonth(currentMonth);
  
  // Mock data for insights
  const dreamInsights = [
    { name: 'Joy', value: 42 },
    { name: 'Anxiety', value: 28 },
    { name: 'Confusion', value: 19 },
    { name: 'Peace', value: 15 }
  ];
  
  const dreamSymbols = [
    { name: 'Water', count: 12 },
    { name: 'Flying', count: 8 },
    { name: 'Falling', count: 6 },
    { name: 'Family', count: 5 }
  ];
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden mb-8">
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
            <div className="flex items-center">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-blue-500 rounded-full mr-4"></div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
                  {userProfile?.name || 'Dream Explorer'}
                </h1>
                <p className="text-slate-600 dark:text-slate-400">
                  Joined {userProfile?.joinDate || 'February 2025'}
                </p>
              </div>
            </div>
            
            <button
              className="mt-4 md:mt-0 px-4 py-2 flex items-center text-sm font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 rounded-lg transition-colors"
            >
              <Settings className="h-4 w-4 mr-2" />
              <span>Account Settings</span>
            </button>
          </div>
          
          <div className="flex flex-col sm:flex-row items-start justify-between">
            <div className="grid grid-cols-2 gap-4 w-full sm:w-auto">
              <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-4">
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">Total Dreams</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">47</p>
              </div>
              <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-4">
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">Dream Streak</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">12 days</p>
              </div>
            </div>
            
            <div className="mt-4 sm:mt-0 w-full sm:w-auto bg-slate-50 dark:bg-slate-700 rounded-lg p-4">
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-2">Most Common Dream Theme</p>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-purple-500 mr-2"></div>
                <p className="font-medium text-slate-900 dark:text-white">Flying & Freedom</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex overflow-x-auto mb-6">
        <button
          onClick={() => setActiveTab('journal')}
          className={`px-4 py-2 font-medium text-sm flex items-center whitespace-nowrap ${
            activeTab === 'journal'
              ? 'text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Calendar className="h-4 w-4 mr-2" />
          Dream Journal
        </button>
        <button
          onClick={() => setActiveTab('insights')}
          className={`px-4 py-2 font-medium text-sm flex items-center whitespace-nowrap ${
            activeTab === 'insights'
              ? 'text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <LineChart className="h-4 w-4 mr-2" />
          Dream Insights
        </button>
        <button
          onClick={() => setActiveTab('saved')}
          className={`px-4 py-2 font-medium text-sm flex items-center whitespace-nowrap ${
            activeTab === 'saved'
              ? 'text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Bookmark className="h-4 w-4 mr-2" />
          Saved Dreams
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-4 py-2 font-medium text-sm flex items-center whitespace-nowrap ${
            activeTab === 'history'
              ? 'text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Clock className="h-4 w-4 mr-2" />
          Dream History
        </button>
      </div>
      
      {activeTab === 'journal' && (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <button
                onClick={goToPreviousMonth}
                className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400"
                aria-label="Previous month"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <h2 className="text-xl font-semibold text-slate-900 dark:text-white">
                {formattedMonth}
              </h2>
              <button
                onClick={goToNextMonth}
                className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400"
                aria-label="Next month"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
            
            <div className="grid grid-cols-7 gap-1">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="text-center py-2 text-sm font-medium text-slate-500 dark:text-slate-400">
                  {day}
                </div>
              ))}
              
              {calendarDays.map((day, index) => (
                <div 
                  key={index}
                  className={`aspect-square p-1 ${
                    day.isCurrentMonth 
                      ? 'bg-white dark:bg-slate-800' 
                      : 'bg-slate-50 dark:bg-slate-700'
                  }`}
                >
                  {day.day && (
                    <div 
                      className={`w-full h-full rounded-lg flex flex-col items-center justify-center ${
                        day.hasDream 
                          ? 'bg-purple-50 dark:bg-purple-900/20 hover:bg-purple-100 dark:hover:bg-purple-900/30 cursor-pointer' 
                          : 'hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer'
                      }`}
                    >
                      <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                        {day.day}
                      </span>
                      {day.hasDream && (
                        <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mt-1"></div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            <div className="mt-6">
              <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">Recent Dreams</h3>
              
              {userDreams && userDreams.length > 0 ? (
                <div className="space-y-4">
                  {userDreams.map(dream => (
                    <DreamCard key={dream.id} dream={{
                      id: dream.id,
                      title: `Dream on ${new Date(dream.date).toLocaleDateString()}`,
                      content: dream.content,
                      emotions: dream.emotions,
                      author: 'You',
                      likes: 0,
                      comments: 0,
                      date: dream.date,
                      tags: ['personal', ...dream.emotions.map(e => e.toLowerCase())]
                    }} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-slate-600 dark:text-slate-400 mb-4">
                    You haven't recorded any dreams yet.
                  </p>
                  <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg shadow-md transition-colors">
                    Log Your First Dream
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      {activeTab === 'insights' && (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-6">
              Dream Insights
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-4">
                  Emotional Patterns
                </h3>
                <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-4">
                  <div className="space-y-4">
                    {dreamInsights.map(emotion => (
                      <div key={emotion.name}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-slate-700 dark:text-slate-300">{emotion.name}</span>
                          <span className="text-slate-500 dark:text-slate-400">{emotion.value}%</span>
                        </div>
                        <div className="w-full bg-slate-200 dark:bg-slate-600 rounded-full h-2">
                          <div 
                            className="bg-purple-500 h-2 rounded-full" 
                            style={{ width: `${emotion.value}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-4">
                  Common Symbols
                </h3>
                <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-4">
                  <div className="space-y-4">
                    {dreamSymbols.map(symbol => (
                      <div key={symbol.name} className="flex items-center">
                        <div className="w-3 h-3 rounded-full bg-indigo-500 mr-3"></div>
                        <div className="flex-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-slate-700 dark:text-slate-300">{symbol.name}</span>
                            <span className="text-slate-500 dark:text-slate-400">{symbol.count} dreams</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-4">
                AI Insights
              </h3>
              <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-4">
                <p className="text-slate-700 dark:text-slate-300 mb-3">
                  Based on your dream patterns, our AI has discovered these insights:
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="w-5 h-5 rounded-full bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 text-xs flex items-center justify-center mr-2 mt-0.5 font-semibold">
                      1
                    </div>
                    <span className="text-slate-700 dark:text-slate-300">
                      Your recurring water symbols may reflect emotional depth and transition in your life.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-5 h-5 rounded-full bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 text-xs flex items-center justify-center mr-2 mt-0.5 font-semibold">
                      2
                    </div>
                    <span className="text-slate-700 dark:text-slate-300">
                      Flying dreams coincide with periods of increased creativity and confidence.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-5 h-5 rounded-full bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 text-xs flex items-center justify-center mr-2 mt-0.5 font-semibold">
                      3
                    </div>
                    <span className="text-slate-700 dark:text-slate-300">
                      Anxiety-related dreams have decreased by 15% over the past month.
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {activeTab === 'saved' && (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-6">
              Saved Dreams
            </h2>
            
            <div className="text-center py-8">
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                You haven't saved any community dreams yet.
              </p>
              <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg shadow-md transition-colors">
                Explore Community Dreams
              </button>
            </div>
          </div>
        </div>
      )}
      
      {activeTab === 'history' && (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-6">
              Dream History
            </h2>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-3 flex items-center">
                  <span>March 2025</span>
                  <span className="ml-2 px-2 py-0.5 text-xs bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300 rounded-full">
                    12 dreams
                  </span>
                </h3>
                <div className="border-l-2 border-purple-200 dark:border-purple-800 pl-4 ml-2 space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="relative pb-4">
                      <div className="absolute -left-6 w-4 h-4 rounded-full bg-purple-500"></div>
                      <p className="text-sm text-slate-500 dark:text-slate-400">March {20 - i * 3}, 2025</p>
                      <p className="text-slate-800 dark:text-slate-200 font-medium">
                        {["Flying through clouds", "Lost in a maze", "Meeting an old friend"][i-1]}
                      </p>
                    </div>
                  ))}
                  <button className="text-sm text-purple-600 dark:text-purple-400 hover:underline">
                    View all dreams from March
                  </button>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-3 flex items-center">
                  <span>February 2025</span>
                  <span className="ml-2 px-2 py-0.5 text-xs bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300 rounded-full">
                    15 dreams
                  </span>
                </h3>
                <div className="border-l-2 border-purple-200 dark:border-purple-800 pl-4 ml-2 space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="relative pb-4">
                      <div className="absolute -left-6 w-4 h-4 rounded-full bg-purple-500"></div>
                      <p className="text-sm text-slate-500 dark:text-slate-400">February {25 - i * 5}, 2025</p>
                      <p className="text-slate-800 dark:text-slate-200 font-medium">
                        {["Swimming in deep water", "Falling from a tower", "Speaking a foreign language"][i-1]}
                      </p>
                    </div>
                  ))}
                  <button className="text-sm text-purple-600 dark:text-purple-400 hover:underline">
                    View all dreams from February
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfilePage;