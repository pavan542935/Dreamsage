import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Moon, Brain, Users, ArrowRight } from 'lucide-react';
import TestimonialCard from '../components/home/TestimonialCard';
import FeatureCard from '../components/home/FeatureCard';

const HomePage: React.FC = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  
  const testimonials = [
    {
      quote: "DreamSage helped me understand my recurring dreams about falling. The Jungian interpretation was particularly insightful.",
      author: "Emily K.",
      role: "Yoga Instructor"
    },
    {
      quote: "I've been journaling my dreams for years, but the AI analysis provides perspectives I never considered before.",
      author: "Michael T.",
      role: "Software Engineer"
    },
    {
      quote: "The community aspect is wonderful. It's comforting to know others have similar dream experiences.",
      author: "Sarah L.",
      role: "Teacher"
    }
  ];
  
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, [testimonials.length]);
  
  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <section className="flex flex-col items-center text-center pt-8 md:pt-16 pb-12">
        <div className="mb-6 relative">
          <Moon className="h-16 w-16 md:h-20 md:w-20 text-purple-600 dark:text-purple-400 animate-pulse" />
          <div className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-blue-400 dark:bg-blue-500 animate-ping" />
        </div>
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-slate-900 dark:text-white">
          Unlock the Wisdom of Your Dreams
        </h1>
        <p className="text-xl text-slate-600 dark:text-slate-300 max-w-3xl mb-8">
          DreamSage combines ancient wisdom with modern AI to help you interpret your dreams 
          and discover their hidden meanings.
        </p>
        <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
          <Link to="/log" className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center">
            <span>Log Your Dream</span>
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
          <Link to="/community" className="px-6 py-3 bg-transparent hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white rounded-lg transition-all flex items-center justify-center">
            <span>Explore Community</span>
          </Link>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-12">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-slate-900 dark:text-white">
            Discover Your Dream's Hidden Meaning
          </h2>
          <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            Our platform offers comprehensive dream analysis through multiple psychological frameworks.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <FeatureCard 
            icon={<Brain className="h-8 w-8 text-purple-600 dark:text-purple-400" />}
            title="AI-Powered Analysis"
            description="Our advanced AI interprets your dreams through Freudian, Jungian, and cognitive psychology frameworks."
          />
          <FeatureCard 
            icon={<Moon className="h-8 w-8 text-blue-500 dark:text-blue-400" />}
            title="Dream Journal"
            description="Record your dreams with emotion tags and symbol highlighting for deeper personal insights."
          />
          <FeatureCard 
            icon={<Users className="h-8 w-8 text-indigo-500 dark:text-indigo-400" />}
            title="Supportive Community"
            description="Share your dreams anonymously and get insights from others experiencing similar dreamscapes."
          />
        </div>
      </section>
      
      {/* How It Works Section */}
      <section className="py-12 bg-white dark:bg-slate-800 rounded-xl shadow-sm">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-slate-900 dark:text-white">
              How DreamSage Works
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
              Our intuitive three-step process helps you gain insights from your dreams.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center mb-4">
                <span className="text-xl font-bold text-purple-600 dark:text-purple-400">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-slate-900 dark:text-white">Log Your Dream</h3>
              <p className="text-slate-600 dark:text-slate-300">
                Record your dream in detail, tagging emotions and highlighting important symbols.
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mb-4">
                <span className="text-xl font-bold text-blue-600 dark:text-blue-400">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-slate-900 dark:text-white">Receive AI Analysis</h3>
              <p className="text-slate-600 dark:text-slate-300">
                Get instant interpretations based on multiple psychological frameworks.
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center mb-4">
                <span className="text-xl font-bold text-indigo-600 dark:text-indigo-400">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-slate-900 dark:text-white">Gain Insights</h3>
              <p className="text-slate-600 dark:text-slate-300">
                Discover patterns, reflect on interpretations, and share with the community if desired.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section className="py-12">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-slate-900 dark:text-white">
            What Our Dreamers Say
          </h2>
          <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            Join thousands who have gained deeper insights into their subconscious.
          </p>
        </div>
        
        <div className="overflow-hidden relative">
          <div 
            className="flex transition-transform duration-500 ease-in-out"
            style={{ transform: `translateX(-${currentTestimonial * 100}%)` }}
          >
            {testimonials.map((testimonial, index) => (
              <div key={index} className="w-full flex-shrink-0">
                <TestimonialCard 
                  quote={testimonial.quote}
                  author={testimonial.author}
                  role={testimonial.role}
                />
              </div>
            ))}
          </div>
          
          <div className="flex justify-center mt-6 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full ${
                  currentTestimonial === index 
                    ? 'bg-purple-600 dark:bg-purple-400' 
                    : 'bg-slate-300 dark:bg-slate-700'
                }`}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-12 bg-gradient-to-r from-purple-600 to-indigo-600 dark:from-purple-800 dark:to-indigo-800 rounded-xl text-white">
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Unlock Your Dreams?
          </h2>
          <p className="text-lg text-purple-100 max-w-2xl mx-auto mb-8">
            Join our community of dreamers and get personalized insights into your subconscious.
          </p>
          <Link 
            to="/log" 
            className="px-8 py-3 bg-white text-purple-700 rounded-lg shadow-lg hover:shadow-xl transition-all inline-flex items-center"
          >
            <span>Start Dream Journal</span>
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;