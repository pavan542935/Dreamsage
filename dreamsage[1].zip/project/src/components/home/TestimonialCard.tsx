import React from 'react';
import { Quote } from 'lucide-react';

interface TestimonialCardProps {
  quote: string;
  author: string;
  role: string;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ quote, author, role }) => {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 mx-auto max-w-2xl">
      <div className="mb-4 text-purple-500 dark:text-purple-400">
        <Quote className="h-8 w-8" />
      </div>
      <p className="text-slate-700 dark:text-slate-300 text-lg mb-6 italic">"{quote}"</p>
      <div className="flex items-center">
        <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-blue-500 rounded-full mr-3"></div>
        <div>
          <p className="font-semibold text-slate-900 dark:text-white">{author}</p>
          <p className="text-sm text-slate-500 dark:text-slate-400">{role}</p>
        </div>
      </div>
    </div>
  );
};

export default TestimonialCard;