import React from 'react';

interface EmotionTagProps {
  emotion: string;
  isSelected: boolean;
  onToggle: () => void;
}

const EmotionTag: React.FC<EmotionTagProps> = ({ emotion, isSelected, onToggle }) => {
  // Map emotions to colors
  const getEmotionColor = (emotion: string): string => {
    const colorMap: Record<string, string> = {
      'Joy': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
      'Fear': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      'Sadness': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      'Anger': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
      'Confusion': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
      'Surprise': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      'Anxiety': 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300',
      'Peace': 'bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-300',
      'Excitement': 'bg-rose-100 text-rose-800 dark:bg-rose-900 dark:text-rose-300',
      'Love': 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300',
    };
    
    return colorMap[emotion] || 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
  };
  
  return (
    <button
      type="button"
      onClick={onToggle}
      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
        isSelected 
          ? `${getEmotionColor(emotion)} ring-2 ring-offset-2 ring-offset-white dark:ring-offset-slate-900 ring-purple-400`
          : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600'
      }`}
    >
      {emotion}
    </button>
  );
};

export default EmotionTag;