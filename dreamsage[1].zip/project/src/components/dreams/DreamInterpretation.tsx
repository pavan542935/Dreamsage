import React, { useState, useEffect } from 'react';
import { Brain, Book, ActivitySquare, Share2 } from 'lucide-react';

interface DreamInterpretationProps {
  dreamContent: string;
  emotions: string[];
}

type Framework = 'freudian' | 'jungian' | 'cognitive';

const DreamInterpretation: React.FC<DreamInterpretationProps> = ({ dreamContent, emotions }) => {
  const [selectedFramework, setSelectedFramework] = useState<Framework>('freudian');
  const [isLoading, setIsLoading] = useState(true);
  
  // Mock interpretations - in a real app these would come from AI analysis
  const interpretations = {
    freudian: {
      title: "Freudian Analysis",
      content: "From a Freudian perspective, this dream appears to represent repressed desires or unresolved conflicts. The symbols present suggest unconscious thoughts seeking expression. The emotional tenor indicates inner tension between your conscious awareness and subconscious drives.",
      insights: [
        "The presence of these symbols may indicate repressed sexual energy",
        "The narrative structure suggests unresolved childhood experiences",
        "Your emotional responses point to internal conflicts seeking resolution"
      ]
    },
    jungian: {
      title: "Jungian Analysis",
      content: "Through a Jungian lens, your dream reveals archetypal patterns from the collective unconscious. The symbols represent aspects of your personal growth journey and integration of shadow elements. This dream is inviting you to become more whole by acknowledging these aspects of yourself.",
      insights: [
        "The central symbols connect to the archetypal journey of transformation",
        "The emotional landscape suggests integration of shadow aspects",
        "The narrative points toward individuation and self-realization"
      ]
    },
    cognitive: {
      title: "Cognitive Analysis",
      content: "From a cognitive psychology perspective, this dream reflects your brain processing recent experiences, emotions, and thoughts. The dream may be consolidating memories and working through problem-solving scenarios. Your emotional responses are connected to recent life events and mental processing.",
      insights: [
        "The dream narrative connects to recent waking experiences and challenges",
        "The emotional content relates to information processing and memory consolidation",
        "The symbols represent your mind categorizing and contextualizing recent events"
      ]
    }
  };
  
  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);
  
  const getFrameworkIcon = (framework: Framework) => {
    switch (framework) {
      case 'freudian':
        return <Brain className="h-5 w-5" />;
      case 'jungian':
        return <Book className="h-5 w-5" />;
      case 'cognitive':
        return <ActivitySquare className="h-5 w-5" />;
      default:
        return <Brain className="h-5 w-5" />;
    }
  };
  
  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden">
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4 text-slate-900 dark:text-white">Dream Interpretation</h2>
        
        {/* Dream content summary */}
        <div className="mb-6 p-4 bg-slate-50 dark:bg-slate-700 rounded-lg">
          <p className="text-slate-700 dark:text-slate-300 italic">{dreamContent.substring(0, 150)}...</p>
          <div className="flex flex-wrap gap-2 mt-2">
            {emotions.map(emotion => (
              <span
                key={emotion}
                className="px-2 py-1 text-xs font-medium bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300 rounded-full"
              >
                {emotion}
              </span>
            ))}
          </div>
        </div>
        
        {/* Framework selector */}
        <div className="flex flex-wrap gap-2 mb-6">
          <button
            onClick={() => setSelectedFramework('freudian')}
            className={`px-4 py-2 rounded-lg flex items-center text-sm font-medium ${
              selectedFramework === 'freudian'
                ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600'
            }`}
          >
            <Brain className="h-4 w-4 mr-2" />
            <span>Freudian</span>
          </button>
          <button
            onClick={() => setSelectedFramework('jungian')}
            className={`px-4 py-2 rounded-lg flex items-center text-sm font-medium ${
              selectedFramework === 'jungian'
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600'
            }`}
          >
            <Book className="h-4 w-4 mr-2" />
            <span>Jungian</span>
          </button>
          <button
            onClick={() => setSelectedFramework('cognitive')}
            className={`px-4 py-2 rounded-lg flex items-center text-sm font-medium ${
              selectedFramework === 'cognitive'
                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600'
            }`}
          >
            <ActivitySquare className="h-4 w-4 mr-2" />
            <span>Cognitive</span>
          </button>
        </div>
        
        {/* Interpretation content */}
        <div 
          className={`transition-opacity duration-300 ${isLoading ? 'opacity-50' : 'opacity-100'}`}
        >
          <div className="flex items-center mb-4">
            {getFrameworkIcon(selectedFramework)}
            <h3 className="text-xl font-semibold ml-2 text-slate-900 dark:text-white">
              {interpretations[selectedFramework].title}
            </h3>
          </div>
          
          <p className="text-slate-700 dark:text-slate-300 mb-6">
            {interpretations[selectedFramework].content}
          </p>
          
          <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-4">
            <h4 className="font-semibold mb-2 text-slate-900 dark:text-white">Key Insights:</h4>
            <ul className="space-y-2">
              {interpretations[selectedFramework].insights.map((insight, index) => (
                <li 
                  key={index}
                  className="flex items-start"
                >
                  <span className="inline-block w-5 h-5 rounded-full bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 text-xs flex items-center justify-center mr-2 mt-0.5 font-semibold">
                    {index + 1}
                  </span>
                  <span className="text-slate-700 dark:text-slate-300">{insight}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      
      <div className="px-6 py-4 bg-slate-50 dark:bg-slate-700 flex justify-between items-center">
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Interpretations are AI-generated and not a substitute for professional therapy.
        </p>
        <button
          className="p-2 rounded-full bg-slate-200 hover:bg-slate-300 dark:bg-slate-600 dark:hover:bg-slate-500 text-slate-700 dark:text-slate-200 transition-colors"
          aria-label="Share interpretation"
        >
          <Share2 className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default DreamInterpretation;