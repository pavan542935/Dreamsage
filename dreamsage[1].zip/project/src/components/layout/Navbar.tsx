import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Moon, Sun, Menu, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const Navbar: React.FC = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isAuthenticated, userProfile } = useAuth();
  const location = useLocation();

  useEffect(() => {
    const isDark = localStorage.getItem('darkMode') === 'true';
    setDarkMode(isDark);
    if (isDark) {
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    localStorage.setItem('darkMode', newDarkMode.toString());
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white dark:bg-slate-900 shadow-md z-50 transition-all duration-300">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2" onClick={closeMenu}>
            <Moon className="h-8 w-8 text-purple-600 dark:text-purple-400" />
            <span className="text-xl font-semibold text-slate-800 dark:text-white">DreamSage</span>
          </Link>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/" 
              className={`text-slate-600 hover:text-purple-600 dark:text-slate-300 dark:hover:text-purple-400 transition-colors ${isActive('/') ? 'text-purple-600 dark:text-purple-400 font-medium' : ''}`}
            >
              Home
            </Link>
            <Link 
              to="/log" 
              className={`text-slate-600 hover:text-purple-600 dark:text-slate-300 dark:hover:text-purple-400 transition-colors ${isActive('/log') ? 'text-purple-600 dark:text-purple-400 font-medium' : ''}`}
            >
              Dream Log
            </Link>
            <Link 
              to="/community" 
              className={`text-slate-600 hover:text-purple-600 dark:text-slate-300 dark:hover:text-purple-400 transition-colors ${isActive('/community') ? 'text-purple-600 dark:text-purple-400 font-medium' : ''}`}
            >
              Community
            </Link>
            {isAuthenticated ? (
              <Link 
                to="/profile" 
                className={`text-slate-600 hover:text-purple-600 dark:text-slate-300 dark:hover:text-purple-400 transition-colors ${isActive('/profile') ? 'text-purple-600 dark:text-purple-400 font-medium' : ''}`}
              >
                Profile
              </Link>
            ) : (
              <button className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors">
                Sign In
              </button>
            )}
            <button 
              onClick={toggleDarkMode}
              className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              aria-label="Toggle dark mode"
            >
              {darkMode ? (
                <Sun className="h-5 w-5 text-yellow-400" />
              ) : (
                <Moon className="h-5 w-5 text-slate-800" />
              )}
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center space-x-4">
            <button 
              onClick={toggleDarkMode}
              className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              aria-label="Toggle dark mode"
            >
              {darkMode ? (
                <Sun className="h-5 w-5 text-yellow-400" />
              ) : (
                <Moon className="h-5 w-5 text-slate-800" />
              )}
            </button>
            <button
              onClick={toggleMenu}
              className="p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              aria-label="Open menu"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6 text-slate-800 dark:text-white" />
              ) : (
                <Menu className="h-6 w-6 text-slate-800 dark:text-white" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white dark:bg-slate-900 shadow-lg py-4 px-4 absolute w-full">
          <div className="flex flex-col space-y-4">
            <Link 
              to="/" 
              className={`text-slate-600 hover:text-purple-600 dark:text-slate-300 dark:hover:text-purple-400 py-2 transition-colors ${isActive('/') ? 'text-purple-600 dark:text-purple-400 font-medium' : ''}`}
              onClick={closeMenu}
            >
              Home
            </Link>
            <Link 
              to="/log" 
              className={`text-slate-600 hover:text-purple-600 dark:text-slate-300 dark:hover:text-purple-400 py-2 transition-colors ${isActive('/log') ? 'text-purple-600 dark:text-purple-400 font-medium' : ''}`}
              onClick={closeMenu}
            >
              Dream Log
            </Link>
            <Link 
              to="/community" 
              className={`text-slate-600 hover:text-purple-600 dark:text-slate-300 dark:hover:text-purple-400 py-2 transition-colors ${isActive('/community') ? 'text-purple-600 dark:text-purple-400 font-medium' : ''}`}
              onClick={closeMenu}
            >
              Community
            </Link>
            {isAuthenticated ? (
              <Link 
                to="/profile" 
                className={`text-slate-600 hover:text-purple-600 dark:text-slate-300 dark:hover:text-purple-400 py-2 transition-colors ${isActive('/profile') ? 'text-purple-600 dark:text-purple-400 font-medium' : ''}`}
                onClick={closeMenu}
              >
                Profile
              </Link>
            ) : (
              <button 
                className="py-2 px-4 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors w-full"
                onClick={closeMenu}
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;