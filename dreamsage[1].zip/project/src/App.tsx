import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Moon } from 'lucide-react';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import HomePage from './pages/HomePage';
import DreamLogPage from './pages/DreamLogPage';
import CommunityPage from './pages/CommunityPage';
import ProfilePage from './pages/ProfilePage';
import { DreamProvider } from './context/DreamContext';
import { AuthProvider } from './context/AuthContext';

function App() {
  return (
    <Router>
      <AuthProvider>
        <DreamProvider>
          <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-blue-50 dark:from-slate-900 dark:to-indigo-950 text-slate-800 dark:text-slate-100">
            <Navbar />
            <div className="container mx-auto px-4 pb-16 pt-20">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/log" element={<DreamLogPage />} />
                <Route path="/community" element={<CommunityPage />} />
                <Route path="/profile" element={<ProfilePage />} />
              </Routes>
            </div>
            <Footer />
          </div>
        </DreamProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;